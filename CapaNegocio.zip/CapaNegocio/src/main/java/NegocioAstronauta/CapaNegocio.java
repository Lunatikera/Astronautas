
package NegocioAstronauta;
import Entidades.Astronauta;
public class CapaNegocio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
    
    public boolean ValidarAstronauta(Astronauta as){
        if(as != null)
        return true;
        else
            return false;
    }
    public boolean ReglasNegocio(Astronauta as){
    if(as.getEdad()<18)
        return false;
    else
        return true;
    }
}
